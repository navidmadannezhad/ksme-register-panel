<template>
    <div class="landing-panel">

        <div class="content">
            <p class="intro">
                انجمن علمی مهندسی مکانیک دانشگاه آزاد واحد کرج
            </p>

            <div class="buttons">
                <NuxtLink to="register">ثبت نام</NuxtLink>
                <a href="https://t.me/KiauKsme">ارتباط با ما</a>
            </div>
        </div>
        
    </div>
</template>

<script>
export default{

    data(){
      return{
       
      }
    },

    methods:{
      

    },

    computed:{
      
    },

    mounted(){
        

    },

    
    created () {
       
    }
}
</script>

<style lang="scss" scoped>
</style>