<template>
    <div class="level4">
        <div class="form">

            <div class="message">
                <p>ثبت نام اولیه شما انجام شد</p>
                <p>برای تکمیل ثبت نام، لطفا به ایمیل خود رجوع کرده و لینکی که برای شما ارسال شده است را تایید کنید.</p>
            </div>

            <!-- <div class="next_level">
                <a href="#">کانال تلگرام انجمن</a>
            </div> -->
        </div>
    </div>
</template>


<script>
export default {

}
</script>