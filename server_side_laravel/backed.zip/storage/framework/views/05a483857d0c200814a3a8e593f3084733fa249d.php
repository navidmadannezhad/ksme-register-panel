

<?php $__env->startSection('content'); ?>
<?php if(isset($user)): ?>
  <div class="users">
      <div class="user" style="<?php echo e($user->is_email_verified == 1 ? 'border-right-color:rgb(15, 134, 15)' : ''); ?>">
        <p class="fullname"><span>نام و نام خانوادگی:</span><span><?php echo e($user->first_name); ?></span> <span><?php echo e($user->last_name); ?></span></p>
        <p class="student_number"><span>شماره دانشجویی:</span><span><?php echo e($user->student_number); ?></span></p>
        <p class="educational_field"><span>رشته تحصیلی:</span><span><?php echo e($user->educational_field); ?></span></p>
        <p class="educational_level"><span>مقطع تحصیلی:</span><span><?php echo e($user->educational_level); ?></span></p>
        <p class="birthday"><span>تاریخ تولد:</span><span><?php echo e($user->birthday); ?></span></p>
        <p class="skills"><span>توانایی ها:</span><span><?php echo e($user->skills); ?></span></p>
        <p class="activities"><span>فعالیت های کاری و پژوهشی:</span><span><?php echo e($user->activities); ?></span></p>
        <p class="email"><span>ایمیل:</span><span><?php echo e($user->email); ?></span></p>
        <p class="corpotate_field"><span>حوزه های همکاری:</span><span><?php echo e($user->corpotate_field); ?></span></p>
        <p class="national_number"><span>کد ملی:</span><span><?php echo e($user->national_number); ?></span></p>
        <p class="extra_words"><span>حرف های دیگر:</span><span><?php echo e($user->extra_words); ?></span></p>
      </div>
  </div>
<?php else: ?>
  <div class="message">
    کاربر مورد نظر یافت نشد
  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\programming\Web Development\projects\ksme-register-panel\server_side_laravel\resources\views/userDetail.blade.php ENDPATH**/ ?>