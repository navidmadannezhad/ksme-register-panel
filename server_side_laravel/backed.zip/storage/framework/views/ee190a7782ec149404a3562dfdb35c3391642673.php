

<?php $__env->startSection('title'); ?>
احراز هویت
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="verification-message">
    <p>
        سلام <?php echo e($full_name); ?>!
    </p>
    <p>
        جهت تایید هویت کاربری در انجمن علمی مهندسی مکانیک بر لینک زیر کلیک کن.
    </p>
    <form action="<?php echo e(route('userVerify', ['token' => $token])); ?>">
        <input type="submit" value="تایید هویت کاربری">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('verification.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\programming\Web Development\projects\ksme-register-panel\server_side_laravel\resources\views/verification/emailTemplate.blade.php ENDPATH**/ ?>