

<?php $__env->startSection('title'); ?>
موفقیت آمیز
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="success">
    <p>
        <?php echo e($message); ?>

    </p>
    <a href="#">
        کانال انجمن علمی مهندسی مکانیک
    </a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('verification.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\programming\Web Development\projects\ksme-register-panel\server_side_laravel\resources\views/verification/success.blade.php ENDPATH**/ ?>