

<?php $__env->startSection('content'); ?>
<?php if(isset($users)): ?>
  <div class="users">
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="user" style="<?php echo e($user->is_email_verified == 1 ? 'border-right-color:rgb(15, 134, 15)' : ''); ?>">
        <p class="fullname"><span>نام و نام خانوادگی:</span><span><?php echo e($user->first_name); ?></span> <span><?php echo e($user->last_name); ?></span></p>
        <p class="student_number"><span>شماره دانشجویی:</span><span><?php echo e($user->student_number); ?></span></p>
        <p class="educational_field"><span>رشته تحصیلی:</span><span><?php echo e($user->educational_field); ?></span></p>
        <p class="educational_level"><span>مقطع تحصیلی:</span><span><?php echo e($user->educational_level); ?></span></p>
        <a href="<?php echo e(route('userDetail', ['id' => $user->id])); ?>">اطلاعات بیشتر</a>
      </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php else: ?>
  <div class="message">
    هنوز کاربری وجود ندارد
  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\programming\Web Development\projects\ksme-register-panel\server_side_laravel\resources\views/home.blade.php ENDPATH**/ ?>